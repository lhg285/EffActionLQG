{{(2*\[Epsilon]^2*\[Mu]^4*(-1 + Cos[kt*\[Lambda]]))/(aa^4*\[Beta]^2), 0, 0, 
  0, 0, 0, 0, 0, 0, -((\[Epsilon]^2*\[Mu]^2*Sin[kt*\[Lambda]])/
    (aa^2*\[Beta])), 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, (-4*\[Epsilon]^2*\[Mu]^2*Sin[(kt*\[Lambda])/2]^2*
    Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])])/(aa^2*P0*\[Beta]), 0, 0, 0, 0, 0, 0, 
  0, 0, -((\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*
       Sin[\[CapitalTheta]0*\[Mu]] - 4*Sin[(kt*\[Lambda])/2]^2*
       Sin[(\[CapitalTheta]0*\[Mu])/2]^2*Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/
    (aa^2*\[Beta]*\[CapitalTheta]0)), 0, 0, 0, 0, 0, 
  (-2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 + Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 
  0}, {0, 0, (-4*\[Epsilon]^2*\[Mu]^2*Sin[(kt*\[Lambda])/2]^2*
    Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])])/(aa^2*P0*\[Beta]), 0, 0, 0, 0, 0, 0, 
  0, 0, -((\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*
       Sin[\[CapitalTheta]0*\[Mu]] - 4*Sin[(kt*\[Lambda])/2]^2*
       Sin[(\[CapitalTheta]0*\[Mu])/2]^2*Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/
    (aa^2*\[Beta]*\[CapitalTheta]0)), 0, 0, 
  (2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 + Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0}, {0, 0, 0, (-4*\[Epsilon]^2*\[Mu]^2*Sin[(kt*\[Lambda])/2]^2*
    Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])])/(aa^2*P0*\[Beta]), 0, 0, 0, 0, 0, 0, 
  0, 0, -((\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*
       Sin[\[CapitalTheta]0*\[Mu]] - 4*Sin[(kt*\[Lambda])/2]^2*
       Sin[(\[CapitalTheta]0*\[Mu])/2]^2*Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/
    (aa^2*\[Beta]*\[CapitalTheta]0)), 0, 0, 
  (2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 + Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0}, {0, 0, 0, 0, (2*\[Epsilon]^2*\[Mu]^4*(-1 + Cos[kt*\[Lambda]]))/
   (aa^4*\[Beta]^2), 0, 0, 0, 0, 0, 0, 0, 0, 
  -((\[Epsilon]^2*\[Mu]^2*Sin[kt*\[Lambda]])/(aa^2*\[Beta])), 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, (-4*\[Epsilon]^2*\[Mu]^2*Sin[(kt*\[Lambda])/2]^2*
    Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])])/(aa^2*P0*\[Beta]), 0, 0, 0, 0, 0, 
  (-2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 + Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, -((\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] - 
      4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
       Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0)), 
  0, 0, 0}, {0, 0, 0, 0, 0, 0, 
  (-4*\[Epsilon]^2*\[Mu]^2*Sin[(kt*\[Lambda])/2]^2*
    Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])])/(aa^2*P0*\[Beta]), 0, 0, 0, 0, 0, 
  (-2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 + Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, -((\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] - 
      4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
       Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0)), 
  0, 0}, {0, 0, 0, 0, 0, 0, 0, 
  (-4*\[Epsilon]^2*\[Mu]^2*Sin[(kt*\[Lambda])/2]^2*
    Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])])/(aa^2*P0*\[Beta]), 0, 0, 
  (2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 + Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, 
  -((\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] - 
      4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
       Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0)), 
  0}, {0, 0, 0, 0, 0, 0, 0, 0, 
  (2*\[Epsilon]^2*\[Mu]^4*(-1 + Cos[kt*\[Lambda]]))/(aa^4*\[Beta]^2), 0, 0, 
  0, 0, 0, 0, 0, 0, -((\[Epsilon]^2*\[Mu]^2*Sin[kt*\[Lambda]])/
    (aa^2*\[Beta]))}, {(\[Epsilon]^2*\[Mu]^2*Sin[kt*\[Lambda]])/
   (aa^2*\[Beta]), 0, 0, 0, 0, 0, 0, 0, 0, 
  (\[Epsilon]^2*(-1 + Cos[kt*\[Lambda]]))/2, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, (\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] + 
     4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, (2*\[Epsilon]^2*\[Mu]*
    (-(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2) + 
     Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, (-8*P0*\[Epsilon]^2*Coth[(2*P0*\[Mu]^2)/(aa^2*\[Beta])]*
    Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0, 0, 0, 0, 
  (4*P0*\[Epsilon]^2*Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0}, 
 {0, 0, (\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] + 
     4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, (2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 - Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, (-8*P0*\[Epsilon]^2*Coth[(2*P0*\[Mu]^2)/(aa^2*\[Beta])]*
    Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0, 
  (-4*P0*\[Epsilon]^2*Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0, 0}, 
 {0, 0, 0, (\[Epsilon]^2*\[Mu]*
    (Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] + 
     4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, (2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 - Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, (-8*P0*\[Epsilon]^2*Coth[(2*P0*\[Mu]^2)/(aa^2*\[Beta])]*
    Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0, 
  (-4*P0*\[Epsilon]^2*Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0}, 
 {0, 0, 0, 0, (\[Epsilon]^2*\[Mu]^2*Sin[kt*\[Lambda]])/(aa^2*\[Beta]), 0, 0, 
  0, 0, 0, 0, 0, 0, (\[Epsilon]^2*(-1 + Cos[kt*\[Lambda]]))/2, 0, 0, 0, 0}, 
 {0, 0, (2*\[Epsilon]^2*\[Mu]*
    (-(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2) + 
     Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, (\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] + 
     4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, (4*P0*\[Epsilon]^2*Sin[kt*\[Lambda]]*
    Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/(aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 
  0, (-8*P0*\[Epsilon]^2*Coth[(2*P0*\[Mu]^2)/(aa^2*\[Beta])]*
    Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0, 0}, 
 {0, 0, 0, (2*\[Epsilon]^2*\[Mu]*
    (-(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2) + 
     Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, (\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] + 
     4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, (4*P0*\[Epsilon]^2*Sin[kt*\[Lambda]]*
    Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/(aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 
  0, (-8*P0*\[Epsilon]^2*Coth[(2*P0*\[Mu]^2)/(aa^2*\[Beta])]*
    Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0}, 
 {0, (2*\[Epsilon]^2*\[Mu]*(Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^
       2 - Sin[(kt*\[Lambda])/2]^2*Sin[\[CapitalTheta]0*\[Mu]]*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, 0, 0, 0, (\[Epsilon]^2*\[Mu]*
    (Sin[kt*\[Lambda]]*Sin[\[CapitalTheta]0*\[Mu]] + 
     4*Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2*
      Tanh[(P0*\[Mu]^2)/(aa^2*\[Beta])]))/(aa^2*\[Beta]*\[CapitalTheta]0), 0, 
  0, (-4*P0*\[Epsilon]^2*Sin[kt*\[Lambda]]*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0, 0, 0, 0, 0, 
  (-8*P0*\[Epsilon]^2*Coth[(2*P0*\[Mu]^2)/(aa^2*\[Beta])]*
    Sin[(kt*\[Lambda])/2]^2*Sin[(\[CapitalTheta]0*\[Mu])/2]^2)/
   (aa^2*\[Beta]*\[CapitalTheta]0^2), 0}, {0, 0, 0, 0, 0, 0, 0, 0, 
  (\[Epsilon]^2*\[Mu]^2*Sin[kt*\[Lambda]])/(aa^2*\[Beta]), 0, 0, 0, 0, 0, 0, 
  0, 0, (\[Epsilon]^2*(-1 + Cos[kt*\[Lambda]]))/2}}
